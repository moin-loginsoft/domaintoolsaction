import logging
import json
import azure.functions as func
from os import environ
import requests



def main(req: func.HttpRequest) -> func.HttpResponse:
    
    logging.info(f'Resource Requested: {func.HttpRequest}')

    try:
        api_key = environ['APIKey']
        api_username = environ['APIUsername']
        url = f"https://api.domaintools.com/v1/iris-investigate/?api_username={api_username}&api_key={api_key}"

        headers = {"accept": "application/json"}

        tagged_with_all = req.params.get('tagged_with_all')
        active = req.params.get('active')
        create_date = req.params.get('create_date')
        expiration_date = req.params.get('expiration_date')

        if not tagged_with_all:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                tagged_with_all = req_body.get('tagged_with_all')
                active = req_body.get('active')
                create_date = req_body.get('create_date')
                expiration_date = req_body.get('expiration_date')
        params = {"tagged_with_all": tagged_with_all}
        if active:
             params['active'] = active
        if create_date:
             params['create_date'] = create_date
        if expiration_date:
             params['expiration_date'] = expiration_date

        response = requests.request("GET", url, headers=headers, params=params)
        return func.HttpResponse(
                    json.dumps(response.json()),
                    headers = {"Content-Type": "application/json"},
                    status_code = 200
                )

    except KeyError as ke:
        logging.error(f'Invalid Settings. {ke.args} configuration is missing.')
        return func.HttpResponse(
             'Invalid Settings. Configuration is missing.',
             status_code=500
        )
    except Exception as ex:
            logging.error(f"Exception Occured: {str(ex)}")
            return func.HttpResponse("Internal Server Exception", status_code=500)
